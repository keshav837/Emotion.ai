# EmotionAI — Real-Time Facial Expression Analysis

A browser-based learning project for facial-expression classification. It uses face-api.js with its Tiny Face Detector and Face Expression Recognition model.

## Run locally
1. Unzip the project.
2. Open a terminal in the project folder.
3. Run a local static server, for example:
   - Python: `python -m http.server 8000`
   - Node: `npx serve .`
4. Open `http://localhost:8000` (or the URL shown by your server) in a modern browser.
5. Allow camera permission and press **Start Camera**.

Camera access generally requires HTTPS or localhost. An internet connection is required to load face-api.js and model weights from their public hosting locations.

## Features
- Home, Live Analysis, About Model, and Privacy sections.
- Webcam access, camera selection, pause/resume/stop.
- Face detection; predictions are shown only when exactly one face is detected.
- Real expression model scores for happy, sad, angry, surprised, fearful, disgusted, neutral.
- Session timeline, distribution, counts, prediction history, CSV export.
- No image/audio recording or application-server upload. Model scripts/weights are downloaded from public hosting.

## Important limitations
- The pretrained model's original training dataset and evaluation metrics are not independently verified here. This project does not claim it was trained/evaluated on FER-2013.
- Expression classification is not a reliable measure of internal emotion, intent, personality, or truth. Do not use it for consequential decisions.
- If the public script or model assets cannot be fetched, the app reports a model loading error and does not generate fake predictions.
